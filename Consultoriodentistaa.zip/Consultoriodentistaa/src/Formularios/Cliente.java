/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Formularios;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 *
 * @author Tony
 */
@Entity
@Table(name = "cliente", catalog = "bancodentista", schema = "")
@NamedQueries({
    @NamedQuery(name = "Cliente.findAll", query = "SELECT c FROM Cliente c"),
    @NamedQuery(name = "Cliente.findByCpf", query = "SELECT c FROM Cliente c WHERE c.cpf = :cpf"),
    @NamedQuery(name = "Cliente.findByRg", query = "SELECT c FROM Cliente c WHERE c.rg = :rg"),
    @NamedQuery(name = "Cliente.findByNome", query = "SELECT c FROM Cliente c WHERE c.nome = :nome"),
    @NamedQuery(name = "Cliente.findByCep", query = "SELECT c FROM Cliente c WHERE c.cep = :cep"),
    @NamedQuery(name = "Cliente.findByTelefone", query = "SELECT c FROM Cliente c WHERE c.telefone = :telefone"),
    @NamedQuery(name = "Cliente.findByProfissao", query = "SELECT c FROM Cliente c WHERE c.profissao = :profissao"),
    @NamedQuery(name = "Cliente.findByEndereco", query = "SELECT c FROM Cliente c WHERE c.endereco = :endereco"),
    @NamedQuery(name = "Cliente.findByPlano", query = "SELECT c FROM Cliente c WHERE c.plano = :plano"),
    @NamedQuery(name = "Cliente.findByProximaconsulta", query = "SELECT c FROM Cliente c WHERE c.proximaconsulta = :proximaconsulta"),
    @NamedQuery(name = "Cliente.findByCustoservi\u00e7o", query = "SELECT c FROM Cliente c WHERE c.custoservi\u00e7o = :custoservi\u00e7o"),
    @NamedQuery(name = "Cliente.findByStatuspagamento", query = "SELECT c FROM Cliente c WHERE c.statuspagamento = :statuspagamento")})
public class Cliente implements Serializable {
    @Transient
    private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "CPF")
    private Long cpf;
    @Basic(optional = false)
    @Column(name = "RG")
    private int rg;
    @Basic(optional = false)
    @Column(name = "Nome")
    private String nome;
    @Basic(optional = false)
    @Column(name = "CEP")
    private int cep;
    @Basic(optional = false)
    @Column(name = "Telefone")
    private long telefone;
    @Basic(optional = false)
    @Column(name = "Profissao")
    private String profissao;
    @Basic(optional = false)
    @Column(name = "Endereco")
    private String endereco;
    @Basic(optional = false)
    @Column(name = "Plano")
    private String plano;
    @Basic(optional = false)
    @Column(name = "Proxima consulta")
    private String proximaconsulta;
    @Basic(optional = false)
    @Column(name = "Custo servi\u00e7o")
    private int custoserviço;
    @Basic(optional = false)
    @Column(name = "Status pagamento")
    private String statuspagamento;

    public Cliente() {
    }

    public Cliente(Long cpf) {
        this.cpf = cpf;
    }

    public Cliente(Long cpf, int rg, String nome, int cep, long telefone, String profissao, String endereco, String plano, String proximaconsulta, int custoserviço, String statuspagamento) {
        this.cpf = cpf;
        this.rg = rg;
        this.nome = nome;
        this.cep = cep;
        this.telefone = telefone;
        this.profissao = profissao;
        this.endereco = endereco;
        this.plano = plano;
        this.proximaconsulta = proximaconsulta;
        this.custoserviço = custoserviço;
        this.statuspagamento = statuspagamento;
    }

    public Long getCpf() {
        return cpf;
    }

    public void setCpf(Long cpf) {
        Long oldCpf = this.cpf;
        this.cpf = cpf;
        changeSupport.firePropertyChange("cpf", oldCpf, cpf);
    }

    public int getRg() {
        return rg;
    }

    public void setRg(int rg) {
        int oldRg = this.rg;
        this.rg = rg;
        changeSupport.firePropertyChange("rg", oldRg, rg);
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        String oldNome = this.nome;
        this.nome = nome;
        changeSupport.firePropertyChange("nome", oldNome, nome);
    }

    public int getCep() {
        return cep;
    }

    public void setCep(int cep) {
        int oldCep = this.cep;
        this.cep = cep;
        changeSupport.firePropertyChange("cep", oldCep, cep);
    }

    public long getTelefone() {
        return telefone;
    }

    public void setTelefone(long telefone) {
        long oldTelefone = this.telefone;
        this.telefone = telefone;
        changeSupport.firePropertyChange("telefone", oldTelefone, telefone);
    }

    public String getProfissao() {
        return profissao;
    }

    public void setProfissao(String profissao) {
        String oldProfissao = this.profissao;
        this.profissao = profissao;
        changeSupport.firePropertyChange("profissao", oldProfissao, profissao);
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        String oldEndereco = this.endereco;
        this.endereco = endereco;
        changeSupport.firePropertyChange("endereco", oldEndereco, endereco);
    }

    public String getPlano() {
        return plano;
    }

    public void setPlano(String plano) {
        String oldPlano = this.plano;
        this.plano = plano;
        changeSupport.firePropertyChange("plano", oldPlano, plano);
    }

    public String getProximaconsulta() {
        return proximaconsulta;
    }

    public void setProximaconsulta(String proximaconsulta) {
        String oldProximaconsulta = this.proximaconsulta;
        this.proximaconsulta = proximaconsulta;
        changeSupport.firePropertyChange("proximaconsulta", oldProximaconsulta, proximaconsulta);
    }

    public int getCustoserviço() {
        return custoserviço;
    }

    public void setCustoserviço(int custoserviço) {
        int oldCustoserviço = this.custoserviço;
        this.custoserviço = custoserviço;
        changeSupport.firePropertyChange("custoservi\u00e7o", oldCustoserviço, custoserviço);
    }

    public String getStatuspagamento() {
        return statuspagamento;
    }

    public void setStatuspagamento(String statuspagamento) {
        String oldStatuspagamento = this.statuspagamento;
        this.statuspagamento = statuspagamento;
        changeSupport.firePropertyChange("statuspagamento", oldStatuspagamento, statuspagamento);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cpf != null ? cpf.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Cliente)) {
            return false;
        }
        Cliente other = (Cliente) object;
        if ((this.cpf == null && other.cpf != null) || (this.cpf != null && !this.cpf.equals(other.cpf))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Formularios.Cliente[ cpf=" + cpf + " ]";
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }
    
}
