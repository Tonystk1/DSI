/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Tony
 */
public class conectabanco {
    public Statement stm; // para realizar consultas
    public ResultSet rs; // para gravar apos consulta
    public Connection conn; //para conectar com o banco de dados
    private final String driver = "com.mysql.jdbc.Driver"; // para conecatar com banco de dados.
    private final String caminho = "jdbc:mysql://localhost:3306/bancodentista";
    private String usuario = "admin";
    private String senha = "";
    
    public void conexao(){ // forma de realizar conexão com banco.
        
        try {
            System.setProperty("jdbc.Drivers", driver); // informa propriedade do driver de conexão.
            conn = DriverManager.getConnection(caminho,usuario,senha);
        } catch (SQLException ex) {
            Logger.getLogger(conectabanco.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null,"Erro ao conectar!\n Erro:" + ex.getMessage()); // informa se a conexão foi bem sucedida ou não
        }
         
    }
    

    public void ExecutaSQL(String sql){
        try {
            stm = conn.createStatement();
            stm.executeUpdate(sql);
            JOptionPane.showMessageDialog(null,"Excluido com sucesso");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"Erro ao Executar SQL!\n Erro:" + ex.getMessage());
        }
    }
    
    public void desconecta(){ // Metodo de encerar conexão
        try {
            conn.close();
            JOptionPane.showMessageDialog(null,"Encerrado com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"Erro ao encerrar conexão!\n Erro:" + ex.getMessage());
        }
    }

    public void executaSQL(String string) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    
}
